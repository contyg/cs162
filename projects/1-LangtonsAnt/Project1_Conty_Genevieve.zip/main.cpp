/********************************************************************* 
** Program name: Langton's Ant
** Author: Genevieve Conty
** Date: 01/20/2019
** Description: TODO: 
TODO: put this on all the files
TODO: add on 
*********************************************************************/
#include <iostream>
#include "menu.hpp"

using std::cout;

int main() 
{	  
    Menu menu;   
    menu.getInfo();
    return 0;
}

