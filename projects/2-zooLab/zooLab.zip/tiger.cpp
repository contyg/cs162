//TODO: description 

#include "Tiger.hpp"

Tiger::Tiger(): Animal(10000, 1, 50,2000) {}