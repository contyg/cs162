//TODO: description 

#ifndef TIGER_H
#define TIGER_H

#include "Animal.hpp"

class Tiger: public Animal {
    public:
        Tiger();
};

#endif