//TODO: description 

#ifndef PENGUIN_H
#define PENGUIN_H

#include "Animal.hpp"


class Penguin: public Animal {

    public:
        Penguin();
};

#endif