#ifndef TURTLE_H
#define TURTLE_H

#include "Animal.hpp"

class Turtle: public Animal {
    public:
        Turtle();
};

#endif