//TODO: description 
#include "Turtle.hpp"

Turtle::Turtle(): Animal( 100, 10, 5, 5) {}