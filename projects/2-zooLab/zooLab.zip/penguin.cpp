//TODO: description 

#include "Penguin.hpp"

Penguin::Penguin(): Animal(1000, 5, 10, 100) {}