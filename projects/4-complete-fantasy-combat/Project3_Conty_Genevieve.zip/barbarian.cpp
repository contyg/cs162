/********************************************************************* 
** Program name: Fantasy Combat 
** Description: Definition of Barbarian Class 
*********************************************************************/

#include "barbarian.hpp"


// int attackDie, int attackSides, int defenseDie, int defenseSides, 
// int armor, int strength, string type
Barbarian::Barbarian() : Character(2, 6, 2, 6, 0, 12, "Barbarian") {}