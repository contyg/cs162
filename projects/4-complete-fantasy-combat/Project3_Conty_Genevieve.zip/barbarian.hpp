/********************************************************************* 
** Program name: Fantasy Combat
** Description: Declaration of Barbarian Class   
*********************************************************************/

#ifndef BARBARIAN_H
#define BARBARIAN_H
#include "character.hpp"

class Barbarian: public Character 
{
public: 
	Barbarian();
};

#endif