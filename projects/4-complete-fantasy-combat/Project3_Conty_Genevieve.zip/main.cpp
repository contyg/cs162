#include <iostream>
#include "menu.hpp"

int main()
{
    Menu menu;
    menu.choosePlayer();
    return 0;
}