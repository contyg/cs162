/********************************************************************* 
** Program name: Doubly-linked List Lab  
** Description: Declaration of menu function  
*********************************************************************/

#ifndef MENU_H
#define MENU_H

void menu();

#endif