#include <iostream>
#include "menu.hpp"

int main()
{
    menu();
    return 0;
}