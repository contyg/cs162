/********************************************************************* 
** Program name: Doubly-linked List Lab  
** Author: Genevieve Conty
** Date: 02/17/2019
** Description: Main file that calls linked list functions
*********************************************************************/

#include <iostream>
#include "menu.hpp"

int main()
{
    menu();
    return 0;
}