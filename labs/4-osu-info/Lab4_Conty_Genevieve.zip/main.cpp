/********************************************************************* 
** Program name: OSU Information System  
** Author: Genevieve Conty
** Date: 02/03/2019
** Description: TODO:  
*********************************************************************/

#include "university.hpp"

int main()
{
    University oregonState;
    oregonState.startMenu();
    return 0;
}