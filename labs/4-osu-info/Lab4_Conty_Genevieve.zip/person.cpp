/********************************************************************* 
** Program: OSU Information System  
** Description: TODO: 
*********************************************************************/
#include "person.hpp"

Person::Person(string n, int a)
{
	name = n;
	age = a;
}

