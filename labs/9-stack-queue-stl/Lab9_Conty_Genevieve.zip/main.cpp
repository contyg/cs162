/********************************************************************* 
** Program name: Stack and Queue STL Containers Lab  
** Author: Genevieve Conty
** Date: 03/10/2019
** Description: Implement linear data structures using STL containers 
*********************************************************************/

#include "menu.hpp"

int main()
{
    mainMenu();
    return 0;
}