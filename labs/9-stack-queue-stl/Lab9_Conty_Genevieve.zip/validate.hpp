/********************************************************************* 
** Program name: Algorithms Lab 
** Description: Declaration of Validation functions   
*********************************************************************/

#ifndef VALIDATE_H
#define VALIDATE_H

int getInteger();
int getIntegerBetween(int min, int max);

#endif