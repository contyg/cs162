/********************************************************************* 
** Program name: Matrix Calculator
** Author: Genevieve Conty
** Date: 01/13/2019
** Description: A matrix calculator for 2x2 and 3x3 matrices 
*********************************************************************/

#ifndef DETERMINANT_H
#define DETERMINANT_H

int determinant(int **matrix, int matrixSize);

#endif