/********************************************************************* 
** Program name: Matrix Calculator
** Author: Genevieve Conty
** Date: 01/13/2019
** Description: A matrix calculator for 2x2 and 3x3 matrices 
*********************************************************************/

#ifndef READMATRIX_H
#define READMATRIX_H

void readMatrix(int **matrix, int matrixSize);

#endif